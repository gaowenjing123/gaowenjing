package com.gao.config;


import com.gao.pojo.Configuration;
import com.gao.pojo.MappedStatement;
import com.gao.sqlSession.SqlCommandType;
import com.mysql.jdbc.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

/**
 * mapper文件
 */
public class XmlMapperConfigBuilder {

    private Configuration configuration;

    public XmlMapperConfigBuilder(Configuration configuration) {
        this.configuration = configuration;
    }

    public void parseConfig(InputStream inputStream) throws DocumentException, ClassNotFoundException {
        Document document = new SAXReader().read(inputStream);  //获取document
        Element rootElement = document.getRootElement(); //获取跟标签
        String nameSpace = rootElement.attributeValue("namespace"); //获取namespace的值
        List<Element> selects = rootElement.selectNodes("select");  //获取select语句的
        for (Element element : selects) {
            String id = element.attributeValue("id");  //唯一标识
            String parameterType = element.attributeValue("paramterType");  //入参类型
            String resultType = element.attributeValue("resultType");   //返回参数类型
            String sql = element.getTextTrim(); //获取sql语句
            String key = nameSpace+"."+id;
            //封装mappedStatement
            MappedStatement mappedStatement = new MappedStatement();
            mappedStatement.setId(id);
            mappedStatement.setParamterType(parameterType);
            mappedStatement.setResultType(resultType);
            mappedStatement.setSql(sql);
            mappedStatement.setSqlCommandType(SqlCommandType.SELECT);
            configuration.getMappedStatementMap().put(key,mappedStatement);
        }
        //增加
        List<Element> inserts = rootElement.selectNodes("insert");  //获取insert语句的
        for (Element element : inserts) {
            String id = element.attributeValue("id");  //唯一标识
            String parameterType = element.attributeValue("paramterType");  //入参类型
            String resultType = element.attributeValue("resultType");   //返回参数类型
            String sql = element.getTextTrim(); //获取sql语句
            String key = nameSpace+"."+id;
            //封装mappedStatement
            MappedStatement mappedStatement = new MappedStatement();
            mappedStatement.setId(id);
            mappedStatement.setParamterType(parameterType);
            mappedStatement.setResultType(resultType);
            mappedStatement.setSql(sql);
            mappedStatement.setSqlCommandType(SqlCommandType.INSERT);
            configuration.getMappedStatementMap().put(key,mappedStatement);
        }

        //删除
        List<Element> deletes = rootElement.selectNodes("delete");  //获取delete语句的
        for (Element element : deletes) {
            String id = element.attributeValue("id");  //唯一标识
            String parameterType = element.attributeValue("paramterType");  //入参类型
            String resultType = element.attributeValue("resultType");   //返回参数类型
            String sql = element.getTextTrim(); //获取sql语句
            String key = nameSpace+"."+id;
            //封装mappedStatement
            MappedStatement mappedStatement = new MappedStatement();
            mappedStatement.setId(id);
            mappedStatement.setParamterType(parameterType);
            mappedStatement.setResultType(resultType);
            mappedStatement.setSql(sql);
            mappedStatement.setSqlCommandType(SqlCommandType.DELETE);
            configuration.getMappedStatementMap().put(key,mappedStatement);
        }

        //修改
        List<Element> updates = rootElement.selectNodes("update");  //获取update语句的
        for (Element element : updates) {
            String id = element.attributeValue("id");  //唯一标识
            String parameterType = element.attributeValue("paramterType");  //入参类型
            String resultType = element.attributeValue("resultType");   //返回参数类型
            String sql = element.getTextTrim(); //获取sql语句
            String key = nameSpace+"."+id;
            //封装mappedStatement
            MappedStatement mappedStatement = new MappedStatement();
            mappedStatement.setId(id);
            mappedStatement.setParamterType(parameterType);
            mappedStatement.setResultType(resultType);
            mappedStatement.setSql(sql);
            mappedStatement.setSqlCommandType(SqlCommandType.UPDATE);
            configuration.getMappedStatementMap().put(key,mappedStatement);
        }




    }

    private Class<?> getClassType(String type) throws ClassNotFoundException {
        Class<?> aClass = Class.forName(type);
        return aClass;
    }

}
