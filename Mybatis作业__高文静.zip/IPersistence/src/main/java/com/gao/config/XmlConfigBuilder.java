package com.gao.config;

import com.gao.io.Resources;
import com.gao.pojo.Configuration;
import com.gao.pojo.MappedStatement;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.beans.PropertyVetoException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

public class XmlConfigBuilder {

    public Configuration configuration;


    public XmlConfigBuilder() {
        this.configuration = new Configuration();
    }

    public Configuration parseConfig(InputStream inputStream) throws DocumentException, PropertyVetoException, ClassNotFoundException {
        Document document = new SAXReader().read(inputStream);
        Element rootElement = document.getRootElement();  //获取sqlMapConfig.xml中根标签
        List<Element> list = rootElement.selectNodes("//property");
        Properties properties = new Properties();
        for (Element element:list) {
            String name = element.attributeValue("name");
            String value = element.attributeValue("value");
            properties.setProperty(name,value);
        }

        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();   //C3P0连接池
        comboPooledDataSource.setDriverClass(properties.getProperty("driverClass"));
        comboPooledDataSource.setJdbcUrl(properties.getProperty("jdbcUrl"));
        comboPooledDataSource.setUser(properties.getProperty("username"));
        comboPooledDataSource.setPassword(properties.getProperty("password"));
        configuration.setDataSource(comboPooledDataSource); //封装数据源对象

        //读取mapper.xml
        List<Element> mapperElements = rootElement.selectNodes("//mapper");
        for (Element mapperElement : mapperElements) {
            String mapperPath =  mapperElement.attributeValue("resource");
            InputStream inputStream1 = Resources.getResourceAsSteam(mapperPath);   //读取一个mapper.xml
            XmlMapperConfigBuilder xmlMapperConfigBuilder = new XmlMapperConfigBuilder(configuration);
            xmlMapperConfigBuilder.parseConfig(inputStream1);
        }

        return configuration;
    }
}
