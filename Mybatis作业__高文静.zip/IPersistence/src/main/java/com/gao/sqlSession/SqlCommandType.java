package com.gao.sqlSession;


public enum SqlCommandType {
    INSERT,DELETE,UPDATE,SELECT
}
