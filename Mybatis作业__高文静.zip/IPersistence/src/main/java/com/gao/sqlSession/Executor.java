package com.gao.sqlSession;

import com.gao.pojo.Configuration;
import com.gao.pojo.MappedStatement;

import java.sql.SQLException;
import java.util.List;

public interface Executor {
    <E> List<E> query(Configuration configuration, MappedStatement
            mappedStatement, Object[] param) throws Exception;


    int update(Configuration configuration, MappedStatement mappedStatement,Object[] param) throws SQLException, ClassNotFoundException, Exception;

    void close() throws SQLException;
}
