package com.gao.sqlSession;

import java.sql.SQLException;
import java.util.List;

public interface SqlSession {

    public <T> T getMapper(Class<?> mapperClass);

    public <E> List<E> selectList(String statementId, Object... params) throws
            Exception;
    public <T> T selectOne(String statementId,Object... params) throws
            Exception;

    public int insert(String statementId,Object... params) throws Exception;

    public int update(String statementId,Object... params) throws Exception;

    public int delete(String statementId,Object... params) throws Exception;

    public void close() throws SQLException;


}
