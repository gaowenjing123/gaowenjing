package com.gao.sqlSession;

import com.gao.pojo.Configuration;
import com.gao.pojo.MappedStatement;

import java.lang.reflect.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DefaultSqlSession implements SqlSession {

    private Configuration configuration;

    public DefaultSqlSession(Configuration configuration) {
        this.configuration = configuration;
    }

    //处理器对象
    private Executor simpleExecutor = new SimpleExecutor();

    @Override
    public <T> T getMapper(Class<?> mapperClass) {
        T o = (T) Proxy.newProxyInstance(DefaultSqlSession.class.getClassLoader(), new Class[]{mapperClass}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                String methodName = method.getName();
                String className = method.getDeclaringClass().getName();
                String key = className+"."+methodName;   //sql唯一标识
                MappedStatement mappedStatement = configuration.getMappedStatementMap().get(key);
                Type genericReturnType = method.getGenericReturnType();
                ArrayList arrayList = new ArrayList<> ();
                SqlCommandType sqlCommandType = mappedStatement.getSqlCommandType();
                if(SqlCommandType.SELECT.equals(sqlCommandType)){
                    //判断接口返回类型是否为
                    if(genericReturnType instanceof ParameterizedType) {
                        return selectList(key,args);
                    }
                    return selectOne(key,args);
                }else if(SqlCommandType.INSERT.equals(sqlCommandType)){
                    return insert(key,args);
                }else if(SqlCommandType.DELETE.equals(sqlCommandType)){
                    return delete(key,args);
                }else if(SqlCommandType.UPDATE.equals(sqlCommandType)){
                    return update(key,args);
                }else{
                    return 1;
                }
            }
        });
        return o;
    }

    @Override
    public <E> List<E> selectList(String statementId, Object... params) throws Exception {
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);
        List<Object> query = simpleExecutor.query(configuration, mappedStatement, params);
        return (List<E>) query;
    }

    @Override
    public <T> T selectOne(String statementId, Object... params) throws Exception {
        List<Object> objects = selectList(statementId,params);
        if(objects.size()==1){
            return (T) objects.get(0);
        }else{
            throw new RuntimeException("查询结果为空或不只唯一");
        }
    }

    @Override
    public int insert(String statementId, Object... params) throws Exception {
        return update(statementId,params);
    }

    @Override
    public int update(String statementId, Object... params) throws Exception {
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);
        return simpleExecutor.update(configuration, mappedStatement, params);
    }

    @Override
    public int delete(String statementId, Object... params) throws Exception {
       return update(statementId,params);
    }

    @Override
    public void close() throws SQLException {
        simpleExecutor.close();
    }
}
