package com.gao.sqlSession;

public interface SqlSessionFactory {
    public SqlSession openSqlSession();
}
