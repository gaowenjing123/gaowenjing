package com.gao.io;

import java.io.InputStream;

public class Resources {

    /**
     * 读取配置文件
     * @param path
     * @return
     */
    public static InputStream getResourceAsSteam(String path){
        InputStream resourceAsStream = Resources.class.getClassLoader().getResourceAsStream(path);
        return resourceAsStream;
    }
}
