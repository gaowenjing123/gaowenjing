package com.gao.test;

import com.gao.dao.UserDao;
import com.gao.io.Resources;
import com.gao.pojo.User;
import com.gao.sqlSession.SqlSession;
import com.gao.sqlSession.SqlSessionFactory;
import com.gao.sqlSession.SqlSessionFactoryBuilder;
import org.dom4j.DocumentException;
import org.junit.Test;

import java.beans.PropertyVetoException;
import java.io.InputStream;
import java.util.List;

public class IPersistenceTest {

    /**
     * @throws Exception
     */
    @Test
    public void test() throws Exception {
        InputStream inputStream = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSqlSession();
        List<User> users = sqlSession.selectList("com.gao.dao.UserDao.selectAll");
        for (User user : users) {
            System.out.println(user);
        }
    }

    //代理模式--查询所有
    @Test
    public void test01() throws Exception {
        InputStream inputStream = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSqlSession();
        //获取代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        List<User> users = userDao.findAll();
        for (User user : users) {
            System.out.println(user);
        }
        sqlSession.close();

    }

    //代理模式--按条件查询
    @Test
    public void test02() throws Exception {
        InputStream inputStream = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSqlSession();
        User user = new User();
        user.setId(1);
        user.setUsername("gao");

        //获取代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        User user1 = userDao.findOne(user);

        System.out.println(user1);
        sqlSession.close();

    }


    //代理模式--修改
    @Test
    public void test03() throws Exception {
        InputStream inputStream = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSqlSession();
        User user = new User();
        user.setId(1);
        user.setUsername("gao update");

        //获取代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        userDao.doUpdate(user);
        System.out.println(user);
        sqlSession.close();

    }

    //代理模式--删除
    @Test
    public void test04() throws Exception {
        InputStream inputStream = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSqlSession();
        User user = new User();
        user.setId(1);
        user.setUsername("gao");

        //获取代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        userDao.doDelete(user);
        sqlSession.close();

    }


    //代理模式--添加
    @Test
    public void test05() throws Exception {
        InputStream inputStream = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSqlSession();
        User user = new User();
        user.setId(5);
        user.setUsername("gao");

        //获取代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        userDao.doInsert(user);
        sqlSession.close();

    }
}
