package com.gao.dao;

import com.gao.pojo.User;

import java.util.List;


public interface UserDao {
    //查询所有用户
    public List<User> findAll() throws Exception;

    //根据条件查询
    public User findOne(User user) throws Exception;

    //添加
    public void doInsert(User user);

    //修改
    public void doUpdate(User user);

    //删除
    public void doDelete(User user);
}
